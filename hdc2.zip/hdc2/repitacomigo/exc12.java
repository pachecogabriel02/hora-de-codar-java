
public class 12Exercicio {
    public static void main(String[] args) {

int contagem = 10
int ultimo = 0


while (contagem > ultimo) {
    System.out.println (contagem );
    contagem = contagem -=1;
}

    }
}
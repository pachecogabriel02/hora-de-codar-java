public class 11Exercicio {
    public static void main(String[] args) {

    int contagem = 30;
   
    while (contagem > 0) {
    String textcontagem = "💣" + "Contagem em " + contagem + "💣" +"<br> <br>";
    System.out.println(textcontagem);
    contagem = contagem - 1;
}

 System.out.println("Explosão");

    }
}